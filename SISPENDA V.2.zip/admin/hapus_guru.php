<?php
// admin/hapus_guru.php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../auth/login.php");
    exit();
}
require_once '../config/config.php';

$id = $_GET['id'] ?? null;
if ($id) {
    $stmt = $pdo->prepare("DELETE FROM guru WHERE id = ?");
    if ($stmt->execute([$id])) {
        header("Location: input_guru.php");
        exit();
    } else {
        echo "Gagal menghapus data guru.";
    }
} else {
    echo "ID guru tidak ditemukan.";
}
