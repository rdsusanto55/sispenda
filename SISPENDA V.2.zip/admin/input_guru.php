<?php
// admin/input_guru.php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../auth/login.php");
    exit();
}
require_once '../config/config.php';

$success = '';
$error = '';

// Proses tambah data guru secara manual
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['import_excel'])) {
        // Handle import dari Excel (tab-delimited)
        if (isset($_FILES['excel_file']) && $_FILES['excel_file']['error'] == 0) {
            $file = $_FILES['excel_file']['tmp_name'];
            $handle = fopen($file, "r");
            while (($data = fgetcsv($handle, 1000, "\t")) !== FALSE) {
                $nama = $data[0];
                $nip = $data[1];
                $password = md5($data[2]); // Pastikan password di Excel sudah di-hash
                // Insert ke database
                $stmt = $pdo->prepare("INSERT INTO guru (nama, nip, password) VALUES (?, ?, ?)");
                $stmt->execute([$nama, $nip, $password]);
            }
            fclose($handle);
            $success = "Data guru berhasil diimport.";
        } else {
            $error = "Gagal mengupload file.";
        }
    } else {
        // Handle tambah guru secara manual
        $nama = trim($_POST['nama']);
        $nip = trim($_POST['nip']);
        $password = md5(trim($_POST['password']));

        // Cek apakah NIP sudah ada
        $stmt = $pdo->prepare("SELECT * FROM guru WHERE nip = ?");
        $stmt->execute([$nip]);
        if ($stmt->rowCount() > 0) {
            $error = "NIP sudah terdaftar.";
        } else {
            $stmt = $pdo->prepare("INSERT INTO guru (nama, nip, password) VALUES (?, ?, ?)");
            if ($stmt->execute([$nama, $nip, $password])) {
                $success = "Data guru berhasil ditambahkan.";
            } else {
                $error = "Gagal menambahkan data guru.";
            }
        }
    }
}

// Ambil data guru yang ada di database untuk ditampilkan
$stmt = $pdo->prepare("SELECT * FROM guru");
$stmt->execute();
$gurus = $stmt->fetchAll();
?>

<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Data Guru</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
        }
    </style>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-4">
        <h2 class="text-2xl font-bold mb-6">Input Data Guru</h2>
        <?php if ($success): ?>
            <p class="text-green-500 mb-4"><?php echo $success; ?></p>
        <?php endif; ?>
        <?php if ($error): ?>
            <p class="text-red-500 mb-4"><?php echo $error; ?></p>
        <?php endif; ?>

        <!-- Form Tambah Guru -->
        <div class="bg-white p-6 rounded-lg shadow-lg mb-6">
            <h3 class="text-xl font-bold mb-4">Tambah Guru Baru</h3>
            <form method="POST">
                <div class="mb-4">
                    <label class="block text-gray-700" for="nama">Nama:</label>
                    <input class="w-full p-2 border border-gray-300 rounded mt-1" type="text" name="nama" id="nama" required>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700" for="nip">NIP:</label>
                    <input class="w-full p-2 border border-gray-300 rounded mt-1" type="text" name="nip" id="nip" required>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700" for="password">Password:</label>
                    <input class="w-full p-2 border border-gray-300 rounded mt-1" type="password" name="password" id="password" required>
                </div>
                <button class="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600 transition duration-200" type="submit">Tambah Guru</button>
            </form>
        </div>

        <!-- Form Import Data Guru -->
        <div class="bg-white p-6 rounded-lg shadow-lg mb-6">
            <h3 class="text-xl font-bold mb-4">Import Data Guru dari Excel</h3>
            <form method="POST" enctype="multipart/form-data">
                <div class="mb-4">
                    <label class="block text-gray-700" for="excel_file">File Excel (Tab-Delimited):</label>
                    <input class="w-full p-2 border border-gray-300 rounded mt-1" type="file" name="excel_file" id="excel_file" accept=".txt,.tsv,.csv" required>
                </div>
                <button class="w-full bg-green-500 text-white p-2 rounded hover:bg-green-600 transition duration-200" type="submit" name="import_excel">Import</button>
            </form>
        </div>

        <!-- Daftar Guru -->
        <div class="bg-white p-6 rounded-lg shadow-lg">
            <h3 class="text-xl font-bold mb-4">Daftar Guru</h3>
            <table class="w-full border-collapse">
                <thead>
                    <tr>
                        <th class="border p-2">Nama</th>
                        <th class="border p-2">NIP</th>
                        <th class="border p-2">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($gurus as $guru): ?>
                        <tr>
                            <td class="border p-2"><?php echo htmlspecialchars($guru['nama']); ?></td>
                            <td class="border p-2"><?php echo htmlspecialchars($guru['nip']); ?></td>
                            <td class="border p-2">
                                <a class="text-blue-500 hover:underline" href="edit_guru.php?id=<?php echo $guru['id']; ?>">Edit</a> | 
                                <a class="text-red-500 hover:underline" href="hapus_guru.php?id=<?php echo $guru['id']; ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="text-center mt-4">
            <a class="text-blue-500 hover:underline" href="dashboard.php">Kembali ke Dashboard</a>
        </div>
    </div>
</body>
</html>