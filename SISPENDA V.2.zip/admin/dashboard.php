<?php
// admin/dashboard.php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../auth/login.php");
    exit();
}
?>

<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
        }
    </style>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-4">
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-3xl font-bold">Selamat Datang, Admin</h1>
            <div class="flex space-x-4">
                <a href="../auth/logout.php" class="text-gray-700 hover:text-gray-900">
                    <i class="fas fa-sign-out-alt text-2xl"></i>
                </a>
            </div>
        </div>

        <!-- Menu Aplikasi -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <a href="input_guru.php" class="bg-blue-500 text-white p-4 rounded-lg shadow-lg flex items-center justify-between">
                <span>Input Data Guru</span>
                <i class="fas fa-user-plus"></i>
            </a>
            <a href="pengumuman.php" class="bg-green-500 text-white p-4 rounded-lg shadow-lg flex items-center justify-between">
                <span>Input Pengumuman</span>
                <i class="fas fa-bullhorn"></i>
            </a>
        </div>
    </div>
</body>
</html>