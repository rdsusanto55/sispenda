<?php
// admin/edit_guru.php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../auth/login.php");
    exit();
}
require_once '../config/config.php';

$error = '';
$success = '';

// Ambil data guru berdasarkan ID
$id = $_GET['id'] ?? null;
if ($id) {
    $stmt = $pdo->prepare("SELECT * FROM guru WHERE id = ?");
    $stmt->execute([$id]);
    $guru = $stmt->fetch();

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $nama = trim($_POST['nama']);
        $nip = trim($_POST['nip']);
        $password = md5(trim($_POST['password']));

        $stmt = $pdo->prepare("UPDATE guru SET nama = ?, nip = ?, password = ? WHERE id = ?");
        if ($stmt->execute([$nama, $nip, $password, $id])) {
            $success = "Data guru berhasil diupdate.";
        } else {
            $error = "Gagal mengupdate data guru.";
        }
    }
} else {
    header("Location: input_guru.php");
    exit();
}

?>

<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data Guru</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
        }
    </style>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-md">
        <h2 class="text-2xl font-bold text-center mb-6">Edit Data Guru</h2>
        <?php if ($success): ?>
            <p class="text-green-500 text-center mb-4"><?php echo $success; ?></p>
        <?php endif; ?>
        <?php if ($error): ?>
            <p class="text-red-500 text-center mb-4"><?php echo $error; ?></p>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-4">
                <label class="block text-gray-700" for="nama">Nama:</label>
                <input class="w-full p-2 border border-gray-300 rounded mt-1" type="text" name="nama" id="nama" value="<?php echo htmlspecialchars($guru['nama']); ?>" required>
            </div>
            <div class="mb-4">
                <label class="block text-gray-700" for="nip">NIP:</label>
                <input class="w-full p-2 border border-gray-300 rounded mt-1" type="text" name="nip" id="nip" value="<?php echo htmlspecialchars($guru['nip']); ?>" required>
            </div>
            <div class="mb-4">
                <label class="block text-gray-700" for="password">Password:</label>
                <input class="w-full p-2 border border-gray-300 rounded mt-1" type="password" name="password" id="password" required>
            </div>
            <button class="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600 transition duration-200" type="submit">Update Data</button>
        </form>
    </div>
</body>
</html>
