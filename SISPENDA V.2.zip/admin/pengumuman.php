<?php
// admin/pengumuman.php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../auth/login.php");
    exit();
}
require_once '../config/config.php';

$success = '';
$error = '';

// Proses tambah pengumuman
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $judul = trim($_POST['judul']);
    $tanggal = $_POST['tanggal'];
    $isi = trim($_POST['isi']);
    $ditujukan_kepada = '';

    if (isset($_POST['semua'])) {
        $ditujukan_kepada = 'semua';
    } else {
        if (isset($_POST['guru'])) {
            $ditujukan_kepada = implode(',', $_POST['guru']);
        }
    }

    // Insert pengumuman ke database
    $stmt = $pdo->prepare("INSERT INTO pengumuman (judul, tanggal, isi, ditujukan_kepada) VALUES (?, ?, ?, ?)");
    if ($stmt->execute([$judul, $tanggal, $isi, $ditujukan_kepada])) {
        $pengumuman_id = $pdo->lastInsertId();

        // Tentukan guru yang menerima pengumuman
        if ($ditujukan_kepada == 'semua') {
            $stmt_guru = $pdo->query("SELECT id FROM guru");
            $guru_ids = $stmt_guru->fetchAll(PDO::FETCH_COLUMN);
        } else {
            $guru_ids = $_POST['guru'];
        }

        // Insert notifikasi untuk guru yang menerima pengumuman
        $stmt_notif = $pdo->prepare("INSERT INTO notifikasi (guru_id, pengumuman_id) VALUES (?, ?)");
        foreach ($guru_ids as $guru_id) {
            $stmt_notif->execute([$guru_id, $pengumuman_id]);
        }

        $success = "Pengumuman berhasil ditambahkan.";
    } else {
        $error = "Gagal menambahkan pengumuman.";
    }
}

// Ambil semua pengumuman yang sudah ada
$stmt = $pdo->query("SELECT * FROM pengumuman ORDER BY tanggal DESC");
$pengumumans = $stmt->fetchAll();

// Ambil semua guru untuk pilihan
$stmt_guru = $pdo->query("SELECT id, nama, nip FROM guru");
$gurus = $stmt_guru->fetchAll();

// Proses hapus pengumuman
if (isset($_GET['hapus']) && is_numeric($_GET['hapus'])) {
    $pengumuman_id = $_GET['hapus'];
    $stmt = $pdo->prepare("DELETE FROM pengumuman WHERE id = ?");
    if ($stmt->execute([$pengumuman_id])) {
        $stmt_notif = $pdo->prepare("DELETE FROM notifikasi WHERE pengumuman_id = ?");
        $stmt_notif->execute([$pengumuman_id]);
        $success = "Pengumuman berhasil dihapus.";
    } else {
        $error = "Gagal menghapus pengumuman.";
    }
}
?>

<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Pengumuman</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <script src="https://cdn.ckeditor.com/4.21.0/standard/ckeditor.js"></script>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
        }
    </style>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-4">
        <h2 class="text-2xl font-bold mb-6">Input Pengumuman</h2>

        <?php if ($success): ?>
            <p class="text-green-500 mb-4"><?php echo $success; ?></p>
        <?php endif; ?>
        <?php if ($error): ?>
            <p class="text-red-500 mb-4"><?php echo $error; ?></p>
        <?php endif; ?>

        <!-- Form untuk input pengumuman -->
        <div class="bg-white p-6 rounded-lg shadow-lg mb-6">
            <form method="POST">
                <div class="mb-4">
                    <label class="block text-gray-700" for="judul">Judul:</label>
                    <input class="w-full p-2 border border-gray-300 rounded mt-1" type="text" name="judul" id="judul" required>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700" for="tanggal">Tanggal:</label>
                    <input class="w-full p-2 border border-gray-300 rounded mt-1" type="date" name="tanggal" id="tanggal" required>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700" for="isi">Isi Pengumuman:</label>
                    <textarea class="w-full p-2 border border-gray-300 rounded mt-1" name="isi" id="isi" rows="5" required></textarea>
                    <script>
                        CKEDITOR.replace('isi');
                    </script>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700">Ditujukan Kepada:</label>
                    <div class="flex items-center mb-2">
                        <input class="mr-2" type="checkbox" name="semua" id="semua" value="semua">
                        <label for="semua">Semua Guru</label>
                    </div>
                    <label for="guru">Pilih Guru:</label>
                    <select class="w-full p-2 border border-gray-300 rounded mt-1" name="guru[]" id="guru" multiple>
                        <?php foreach ($gurus as $guru): ?>
                            <option value="<?php echo $guru['id']; ?>"><?php echo $guru['nama'] . " (" . $guru['nip'] . ")"; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button class="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600 transition duration-200" type="submit" name="tambah_pengumuman">Tambah Pengumuman</button>
            </form>
        </div>

        <!-- Tabel untuk menampilkan pengumuman yang sudah ada -->
        <div class="bg-white p-6 rounded-lg shadow-lg">
            <h3 class="text-xl font-bold mb-4">Daftar Pengumuman</h3>
            <?php if (count($pengumumans) > 0): ?>
                <table class="w-full border-collapse">
                    <thead>
                        <tr>
                            <th class="border p-2">Judul</th>
                            <th class="border p-2">Tanggal</th>
                            <th class="border p-2">Ditujukan Kepada</th>
                            <th class="border p-2">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pengumumans as $pengumuman): ?>
                            <tr>
                                <td class="border p-2"><?php echo htmlspecialchars($pengumuman['judul']); ?></td>
                                <td class="border p-2"><?php echo htmlspecialchars($pengumuman['tanggal']); ?></td>
                                <td class="border p-2">
                                    <?php echo $pengumuman['ditujukan_kepada'] == 'semua' ? 'Semua Guru' : 'Beberapa Guru'; ?>
                                </td>
                                <td class="border p-2">
                                    <a class="text-red-500 hover:underline" href="?hapus=<?php echo $pengumuman['id']; ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus pengumuman ini?')">Hapus</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>Belum ada pengumuman yang ditambahkan</p>
            <?php endif; ?>
        </div>

        <div class="text-center mt-4">
            <a class="text-blue-500 hover:underline" href="dashboard.php">Kembali ke Dashboard</a>
        </div>
    </div>
</body>
</html>

