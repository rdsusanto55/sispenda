<?php
// auth/login.php
session_start();
require_once '../config/config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Periksa di tabel admin
    $stmt = $pdo->prepare("SELECT * FROM admin WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && md5($password) === $user['password']) {
        // Login sebagai admin
        $_SESSION['admin_logged_in'] = true;
        header("Location: ../admin/dashboard.php");
        exit();
    }

    // Periksa di tabel guru
    $stmt = $pdo->prepare("SELECT * FROM guru WHERE nip = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && md5($password) === $user['password']) {
        // Login sebagai guru
        $_SESSION['guru_logged_in'] = true;
        $_SESSION['guru_id'] = $user['id'];
        header("Location: ../guru/dashboard.php");
        exit();
    }

    // Jika tidak cocok
    $error = "Username atau Password salah.";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta name="description" content="SISPENDA adalah Sistem Informasi SMP Negeri 2 Tungkal Jaya, Aplikasi Guru SMP Negeri 2 Tungkal Jaya adalah platform digital yang menyediakan berbagai fitur penting untuk mendukung pengelolaan administrasi pendidikan.">
    <title>Login SISPENDA</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet"/>
    <link href="https://s3.app.web.id/logourl-1717075409664.png" rel="icon" type="image/png"/>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #F0FDF4;
        }
    </style>
    <script>
        function togglePassword() {
            const passwordField = document.getElementById('password');
            const toggleIcon = document.getElementById('togglePassword');
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            } else {
                passwordField.type = 'password';
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            }
        }
    </script>
</head>
<body class="bg-green-50 font-poppins flex flex-col min-h-screen">
    <div class="container mx-auto px-4 pt-10 flex flex-col md:flex-row items-center justify-center flex-grow">
        <div class="md:w-1/2 text-center md:text-left mb-8 md:mb-0">
            <h1 class="text-4xl font-bold mb-2">Selamat Datang!</h1>
            <p class="text-lg">di Aplikasi <b>SISPENDA</b></p>
            <p class="text-lg font-bold">Sistem Informasi SMP Negeri 2 Tungkal Jaya</p>
            <div class="mt-8 bg-white p-6 rounded-xl shadow-md border border-gray-300" style="border-color: #D2D4DA;">
                <h2 class="text-3xl font-bold mb-1">Masuk Akun</h2>
                <p class="mb-1" style="color: #5b5d6b;">Masukan username & password anda</p>
                <form action="" method="POST">
                    <div class="mb-4">
                        <div class="flex items-center border rounded-xl px-3 py-2" style="border-color: #D2D4DA;">
                            <i class="fas fa-user text-gray-400 mr-2"></i>
                            <input class="w-full border-none focus:outline-none" name="username" placeholder="Masukan Username" required="" type="text"/>
                        </div>
                    </div>
                    <div class="mb-4 relative">
                        <div class="flex items-center border rounded-xl px-3 py-2" style="border-color: #D2D4DA;">
                            <i class="fas fa-lock text-gray-400 mr-2"></i>
                            <input class="w-full border-none focus:outline-none" id="password" name="password" placeholder="Masukan Password" required="" type="password"/>
                            <span class="absolute inset-y-0 right-3 flex items-center cursor-pointer" onclick="togglePassword()">
                                <i class="fas fa-eye text-gray-500" id="togglePassword"></i>
                            </span>
                        </div>
                    </div>
                    <button class="w-full" style="background-color: #075F63; color: white; padding: 0.5rem; border-radius: 0.75rem;" type="submit">Login</button>
                </form>
                <?php if ($error): ?>
                <div class="mt-4 text-red-500 text-center"><?php echo $error; ?></div>
                <?php endif; ?>
            </div>
        </div>
        <div class="md:w-1/2 flex justify-center">
            <img alt="Illustration of a teacher and student in a classroom setting" class="w-full h-auto max-w-xs md:max-w-md" src="https://i.ibb.co.com/47vpZ2z/login-ilustrasi.png"/>
        </div>
    </div>
    <footer class="bg-white py-4 text-center w-full">
        <p>� 2025 SISPENDA Versi 1.2.2. All rights reserved.</p>
        <p>Developed by <a class="text-blue-400 hover:underline" href="https://rdsusanto.my.id">Rudy Susanto</a></p>
    </footer>
</body>
</html>