<?php
// auth/logout.php
session_start();

if (isset($_SESSION['admin_logged_in'])) {
    unset($_SESSION['admin_logged_in']);
}

if (isset($_SESSION['guru_logged_in'])) {
    unset($_SESSION['guru_logged_in']);
}

session_destroy();
header("Location: login.php");
exit();
?>
