<?php
// index.php
header("Location: auth/login.php");
exit();
?>
