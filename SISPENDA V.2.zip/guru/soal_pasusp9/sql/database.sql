-- Membuat database smapgri1_upload
CREATE DATABASE IF NOT EXISTS smapgri1_upload;

-- Gunakan database smapgri1_upload
USE smapgri1_upload;

-- Membuat tabel soal_uploads
CREATE TABLE IF NOT EXISTS soal_uploads (
    id INT AUTO_INCREMENT PRIMARY KEY,         -- ID unik untuk setiap soal
    nama_guru VARCHAR(100) NOT NULL,           -- Nama guru pengupload
    kelas ENUM('7', '8', '9') NOT NULL,        -- Kelas (7, 8, atau 9)
    mapel VARCHAR(100) NOT NULL,               -- Mata pelajaran
    file_name VARCHAR(255) NOT NULL,           -- Nama file yang diunggah
    upload_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP -- Waktu upload otomatis
);
