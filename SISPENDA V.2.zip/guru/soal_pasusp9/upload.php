<?php
require 'db.php'; // Panggil koneksi database

// Periksa apakah form telah disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_guru = $_POST['nama_guru'];
    $kelas = $_POST['kelas'];
    $mapel = $_POST['mapel'];

    // Validasi file
    if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
        $file_tmp = $_FILES['file']['tmp_name'];
        $file_ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);

        // Pastikan file memiliki ekstensi yang diizinkan
        $allowed_ext = ['doc', 'docx'];
        if (!in_array($file_ext, $allowed_ext)) {
            die('File yang diunggah harus berupa file Word (.doc, .docx)');
        }

        // Buat nama file baru
        $new_file_name = $nama_guru . '-' . $kelas . '-' . $mapel . '.' . $file_ext;

        // Tentukan lokasi penyimpanan file
        $upload_dir = 'uploads/';
        $upload_path = $upload_dir . $new_file_name;

        // Pindahkan file ke folder uploads
        if (move_uploaded_file($file_tmp, $upload_path)) {
            // Simpan data ke database
            $stmt = $conn->prepare("INSERT INTO soal_uploads (nama_guru, kelas, mapel, file_name) VALUES (?, ?, ?, ?)");
            $stmt->bind_param('ssss', $nama_guru, $kelas, $mapel, $new_file_name);
            $stmt->execute();

            echo 'File berhasil diunggah dan disimpan!, untuk mengecek soal, klik tombol daftar upload';
        } else {
            echo 'Gagal mengunggah file.';
        }
    } else {
        echo 'Tidak ada file yang diunggah.';
    }
} else {
    echo 'Invalid request.';
}
?>
