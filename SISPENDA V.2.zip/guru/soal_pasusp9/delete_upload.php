<?php
require 'db.php'; // Panggil koneksi database

// Cek apakah ID dikirim melalui URL
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // Pastikan ID adalah angka

    // Cek apakah password sudah dikirim
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $password = $_POST['password'];

        // Validasi password
        if ($password === 'smpn2tj@') {
            // Ambil data file dari database berdasarkan ID
            $sql = "SELECT file_name FROM soal_uploads WHERE id = $id";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $data = $result->fetch_assoc();
                $file_name = $data['file_name'];

                // Hapus file dari folder uploads
                $file_path = "uploads/" . $file_name;
                if (file_exists($file_path)) {
                    unlink($file_path); // Hapus file
                }

                // Hapus data dari database
                $delete_sql = "DELETE FROM soal_uploads WHERE id = $id";
                if ($conn->query($delete_sql) === TRUE) {
                    header("Location: hasil_upload.php?message=Data berhasil dihapus");
                    exit;
                } else {
                    echo "Error: " . $conn->error;
                }
            } else {
                echo "Data tidak ditemukan.";
            }
        } else {
            $error = "Password salah. Silakan coba lagi.";
        }
    }
} else {
    echo "ID tidak valid.";
}
?>

<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Konfirmasi Hapus</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"></link>
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Nunito Sans', sans-serif;
        }
    </style>
</head>
<body class="flex flex-col items-center justify-center min-h-screen bg-gray-100">
    <h1 class="text-2xl font-bold mb-4">Konfirmasi Hapus Data</h1>
    <p class="mb-4">Silakan masukkan password untuk menghapus file soal Anda yang salah. JANGAN MENGHAPUS FILE SOAL ORANG LAIN!</p>

    <form method="post" class="bg-white p-6 rounded-lg shadow-md w-full max-w-sm">
        <label for="password" class="block text-sm font-medium text-gray-700 mb-2">Password:</label>
        <input type="password" id="password" name="password" required class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm mb-4">
        <button type="submit" class="w-full bg-red-600 text-white py-2 px-4 rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500">Hapus</button>
    </form>

    <?php if (isset($error)): ?>
        <p class="text-red-500 mt-4"><?php echo $error; ?></p>
    <?php endif; ?>

    <a class="mt-4 text-indigo-600 hover:underline" href="hasil_upload.php">Kembali ke Daftar Upload</a>
</body>
</html>