<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Soal</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"></link>
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Nunito Sans', sans-serif;
        }
    </style>
    <script>
        function closePopup() {
            document.getElementById('popup').style.display = 'none';
        }

        function checkPassword() {
            const password = prompt("Masukkan password untuk mengakses daftar upload");
            if (password === "123456") {
                window.location.href = "https://sispenda.smpn2tj.my.id/guru/soal_pasusp9/hasil_upload.php";
            } else {
                alert("Password salah. Silakan coba lagi.");
            }
        }

        function openPopup() {
            document.getElementById('popup').style.display = 'flex';
        }
    </script>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <div class="bg-white shadow-lg rounded-lg p-8 max-w-lg w-full relative">
        <h1 class="text-2xl font-bold mb-6 text-center text-gray-800">Form Upload Soal</h1>
        
        <div id="popup" class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 rounded-md shadow-md flex items-center mb-6">
            <i class="fas fa-lightbulb mr-2"></i>
            <div>
                <p class="font-bold">Petunjuk:</p>
                <p>Silakan Download terlebih dahulu Format Soal, Soal Eksak 40 Soal PG, Non Eksak 50 Soal PG</p>
            </div>
            <button onclick="closePopup()" class="ml-4 text-yellow-700 hover:text-yellow-900 focus:outline-none">
                <i class="fas fa-times"></i>
            </button>
        </div>

        <div class="mb-6 flex justify-center">
            <a href="unduh.html" class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500">
                <i class="fas fa-download mr-2"></i> Download Format Soal
            </a>
        </div>
        <form action="upload.php" method="POST" enctype="multipart/form-data" class="space-y-6">
            <div>
                <label for="nama_guru" class="block text-sm font-medium text-gray-700">Nama Guru:</label>
                <input type="text" id="nama_guru" name="nama_guru" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
            </div>
            
            <div>
                <label for="kelas" class="block text-sm font-medium text-gray-700">Kelas:</label>
                <select id="kelas" name="kelas" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                </select>
            </div>
            
            <div>
                <label for="mapel" class="block text-sm font-medium text-gray-700">Mata Pelajaran:</label>
                <input type="text" id="mapel" name="mapel" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
            </div>
            
            <div>
                <label for="file" class="block text-sm font-medium text-gray-700">Pilih File (Word):</label>
                <input type="file" id="file" name="file" accept=".doc, .docx" required class="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
            </div>
            
            <div class="flex justify-center">
                <button type="submit" class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                    <i class="fas fa-upload mr-2"></i> Upload
                </button>
            </div>
        </form>

        <div class="mt-6 flex justify-center">
            <button onclick="checkPassword()" class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                <i class="fas fa-list mr-2"></i> Daftar Upload
            </button>
        </div>
    </div>
</body>
</html>