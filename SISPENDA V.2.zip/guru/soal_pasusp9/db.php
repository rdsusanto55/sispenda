<?php
// db.php: File koneksi ke database
$host = 'localhost';
$username = 'smapgri1_upload'; // Username baru
$password = 'Ryuna0106';       // Password baru
$dbname = 'smapgri1_upload';   // Nama database baru

$conn = new mysqli($host, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die('Koneksi gagal: ' . $conn->connect_error);
}
?>
