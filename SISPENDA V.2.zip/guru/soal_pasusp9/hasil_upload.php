<?php
require 'db.php'; // Panggil koneksi database

// Query untuk mengambil semua data dari tabel soal_uploads
$sql = "SELECT * FROM soal_uploads ORDER BY upload_time DESC";
$result = $conn->query($sql);
?>

<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hasil Upload Soal</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"></link>
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Nunito Sans', sans-serif;
        }
    </style>
    <script>
        function filterTable() {
            const input = document.getElementById("searchInput");
            const filter = input.value.toLowerCase();
            const table = document.getElementById("dataTable");
            const rows = table.getElementsByTagName("tr");

            for (let i = 1; i < rows.length; i++) {
                const row = rows[i];
                const cells = row.getElementsByTagName("td");
                let match = false;

                for (let j = 0; j < cells.length; j++) {
                    if (cells[j].innerText.toLowerCase().includes(filter)) {
                        match = true;
                        break;
                    }
                }

                row.style.display = match ? "" : "none";
            }
        }
    </script>
</head>
<body class="bg-gray-100 p-6">
    <h1 class="text-3xl font-bold text-center mb-6">Daftar Hasil Upload Soal</h1>

    <div class="mb-6 flex justify-end">
        <input type="text" id="searchInput" onkeyup="filterTable()" placeholder="Cari data..." class="px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
    </div>

    <?php if ($result->num_rows > 0): ?>
        <div class="overflow-x-auto">
            <table id="dataTable" class="min-w-full bg-white border border-gray-200">
                <thead>
                    <tr>
                        <th class="px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">No</th>
                        <th class="px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nama Guru</th>
                        <th class="px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Kelas</th>
                        <th class="px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Mapel</th>
                        <th class="px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nama File</th>
                        <th class="px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Waktu Upload</th>
                        <th class="px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Link Download</th>
                        <th class="px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th>
                    </tr>
                </thead>
                <tbody class="bg-white">
                    <?php
                    $no = 1;
                    while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td class="px-6 py-4 border-b border-gray-200"><?php echo $no++; ?></td>
                            <td class="px-6 py-4 border-b border-gray-200"><?php echo htmlspecialchars($row['nama_guru']); ?></td>
                            <td class="px-6 py-4 border-b border-gray-200"><?php echo htmlspecialchars($row['kelas']); ?></td>
                            <td class="px-6 py-4 border-b border-gray-200"><?php echo htmlspecialchars($row['mapel']); ?></td>
                            <td class="px-6 py-4 border-b border-gray-200"><?php echo htmlspecialchars($row['file_name']); ?></td>
                            <td class="px-6 py-4 border-b border-gray-200"><?php echo htmlspecialchars($row['upload_time']); ?></td>
                            <td class="px-6 py-4 border-b border-gray-200">
                                <a href="uploads/<?php echo htmlspecialchars($row['file_name']); ?>" download class="text-indigo-600 hover:text-indigo-900">
                                    <button class="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">
                                        <i class="fas fa-download"></i> Download
                                    </button>
                                </a>
                            </td>
                            <td class="px-6 py-4 border-b border-gray-200">
                                <a href="delete_upload.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')" class="text-red-600 hover:text-red-900">
                                    <button class="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700">
                                        <i class="fas fa-trash-alt"></i> Hapus
                                    </button>
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <p class="text-center text-gray-500">Tidak ada data yang diunggah.</p>
    <?php endif; ?>

</body>
</html>