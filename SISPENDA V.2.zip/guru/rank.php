<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['file'])) {
    $fileContent = file_get_contents($_FILES['file']['tmp_name']);
    $lines = explode("\n", trim($fileContent));

    $data = [];
    foreach ($lines as $line) {
        $columns = explode("\t", trim($line));
        $name = array_shift($columns);
        $scores = array_map('floatval', $columns);
        $total = array_sum($scores);
        $average = $total / count($scores);
        $data[] = ['name' => $name, 'scores' => $scores, 'total' => $total, 'average' => $average];
    }

    usort($data, function($a, $b) {
        return $b['total'] <=> $a['total'];
    });

    foreach ($data as $index => &$row) {
        $row['rank'] = $index + 1;
    }
    unset($row);
}
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perhitungan Nilai Siswa</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"></link>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col items-center justify-center">
    <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-lg">
        <h1 class="text-2xl font-bold mb-6 text-center">Penghitungan Nilai Siswa</h1>
        <form method="post" enctype="multipart/form-data" class="space-y-4">
            <div class="flex items-center justify-center w-full">
                <label class="flex flex-col items-center w-full h-32 border-4 border-dashed border-gray-300 hover:border-gray-400 cursor-pointer">
                    <div class="flex flex-col items-center justify-center pt-7">
                        <i class="fas fa-cloud-upload-alt fa-3x text-gray-300"></i>
                        <p class="text-sm text-gray-400 group-hover:text-gray-600 pt-1 tracking-wider">Select a file</p>
                    </div>
                    <input type="file" name="file" class="opacity-0" required onchange="displayFileName(this)">
                </label>
            </div>
            <div id="file-name" class="text-center text-gray-600 mt-2"></div>
            <div class="flex justify-between">
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Proses</button>
            </div>
        </form>
        <div class="mt-6 p-4 bg-gray-100 rounded-lg">
            <div class="flex items-center mb-2">
                <i class="fas fa-lightbulb text-yellow-500 mr-2"></i>
                <h3 class="text-lg font-semibold">Petunjuk:</h3>
            </div>
            <ul class="list-disc list-inside text-gray-700">
                <li>Gunakan Fitur "Save As" di Excel</li>
                <li>Buka file Excel Anda.</li>
                <li>Klik File > Save As (atau Save a Copy di versi Excel yang lebih baru).</li>
                <li>Pilih lokasi penyimpanan file.</li>
                <li>Pada Save as type (Jenis File), pilih Text (Tab delimited) (*.txt).</li>
                <li>Klik Save.</li>
            </ul>
        </div>
    </div>

    <?php if (isset($data)): ?>
        <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-4xl mt-8">
            <h2 class="text-2xl font-bold mb-6 text-center">Hasil Perhitungan</h2>
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white border border-gray-200">
                    <thead>
                        <tr>
                            <th class="py-2 px-4 border-b border-gray-200 bg-gray-100 text-left text-sm font-semibold text-gray-700">Rank</th>
                            <th class="py-2 px-4 border-b border-gray-200 bg-gray-100 text-left text-sm font-semibold text-gray-700">Nama</th>
                            <th class="py-2 px-4 border-b border-gray-200 bg-gray-100 text-left text-sm font-semibold text-gray-700">Nilai</th>
                            <th class="py-2 px-4 border-b border-gray-200 bg-gray-100 text-left text-sm font-semibold text-gray-700">Jumlah</th>
                            <th class="py-2 px-4 border-b border-gray-200 bg-gray-100 text-left text-sm font-semibold text-gray-700">Rata-rata</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($data as $row): ?>
                            <tr class="hover:bg-gray-100">
                                <td class="py-2 px-4 border-b border-gray-200 text-sm text-gray-700"><?php echo $row['rank']; ?></td>
                                <td class="py-2 px-4 border-b border-gray-200 text-sm text-gray-700"><?php echo htmlspecialchars($row['name']); ?></td>
                                <td class="py-2 px-4 border-b border-gray-200 text-sm text-gray-700"><?php echo implode(", ", $row['scores']); ?></td>
                                <td class="py-2 px-4 border-b border-gray-200 text-sm text-gray-700"><?php echo $row['total']; ?></td>
                                <td class="py-2 px-4 border-b border-gray-200 text-sm text-gray-700"><?php echo number_format($row['average'], 2); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>

    <script>
        function displayFileName(input) {
            const fileName = input.files[0].name;
            document.getElementById('file-name').textContent = `Selected file: ${fileName}`;
        }
    </script>
</body>
</html>