<?php
// guru/dashboard.php
session_start();
if (!isset($_SESSION['guru_logged_in'])) {
    header("Location: ../auth/login.php");
    exit();
}
require_once '../config/config.php';

// Ambil data guru
$guru_id = $_SESSION['guru_id'];
$stmt = $pdo->prepare("SELECT * FROM guru WHERE id = ?");
$stmt->execute([$guru_id]);
$guru = $stmt->fetch();

// Ambil notifikasi yang belum dibaca
$stmt_notif = $pdo->prepare("SELECT pengumuman.* FROM notifikasi 
                              JOIN pengumuman ON notifikasi.pengumuman_id = pengumuman.id
                              WHERE notifikasi.guru_id = ? AND notifikasi.dibaca = FALSE");
$stmt_notif->execute([$guru_id]);
$notifs = $stmt_notif->fetchAll();

// Tandai notifikasi sebagai dibaca
$stmt_update = $pdo->prepare("UPDATE notifikasi SET dibaca = TRUE WHERE guru_id = ?");
$stmt_update->execute([$guru_id]);

// Ambil pengumuman yang hanya ditujukan kepada guru ini (baik yang sudah dibaca maupun yang belum)
$stmt_pengumuman = $pdo->prepare("SELECT * FROM pengumuman WHERE ditujukan_kepada LIKE ? OR ditujukan_kepada = 'semua' ORDER BY tanggal DESC");
$stmt_pengumuman->execute(['%' . $guru_id . '%']);
$pengumumans = $stmt_pengumuman->fetchAll();
?>

<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Guru</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Nunito Sans', sans-serif;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        .blink {
            animation: blinker 1.5s linear infinite;
        }
        @keyframes blinker {
            50% { opacity: 0; }
        }
        .floating-button {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: #085F63;
            color: white;
            padding: 10px;
            border-radius: 50%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            z-index: 100;
            transition: background-color 0.3s;
            font-size: 24px; /* Ikon lebih besar */
        }
        .floating-button:hover {
            background-color: #045A61;
        }
    </style>
</head>
<body class="bg-[#F0FDF4] flex flex-col min-h-screen">
    <header class="bg-[#085F63] text-white p-4 flex justify-between items-center w-full fixed top-0 z-50">
        <h1 class="text-2xl font-bold">SISPENDA</h1>
        <div class="flex items-center space-x-6">
            <nav class="flex space-x-4">
                <a href="#notifikasi" class="text-white hover:text-gray-300 relative" id="notif-bell">
                    <i class="fas fa-bell text-2xl"></i>
                    <?php if ($notifs): ?>
                        <span class="absolute top-0 right-0 h-3 w-3 bg-red-500 rounded-full blink"></span>
                    <?php endif; ?>
                </a>
                <a href="ubah_password.php" class="text-white hover:text-gray-300">
                    <i class="fas fa-user-edit text-2xl"></i>
                </a>
                <a href="https://wa.me/6282127618761?text=Hallo,%20saya%20<?php echo urlencode(htmlspecialchars($guru['nama'])); ?>,%20perlu%20bantuan" class="text-white hover:text-gray-300">
                    <i class="fas fa-comments text-2xl"></i>
                </a>
                <a href="../auth/logout.php" class="text-white hover:text-gray-300">
                    <i class="fas fa-sign-out-alt text-2xl"></i>
                </a>
            </nav>
        </div>
    </header>

    <main class="flex-grow mt-16 w-full p-4 sm:px-8 lg:px-16 xl:px-32">
        <div class="bg-gradient-to-r from-green-400 to-blue-500 text-white p-6 rounded-lg shadow-lg mb-6">
            <?php
                date_default_timezone_set('Asia/Jakarta');
                $hour = date('H');
                if ($hour >= 5 && $hour < 12) {
                    $greeting = "Selamat Pagi";
                    $icon = "fas fa-sun";
                } elseif ($hour >= 12 && $hour < 15) {
                    $greeting = "Selamat Siang";
                    $icon = "fas fa-sun";
                } elseif ($hour >= 15 && $hour < 18) {
                    $greeting = "Selamat Sore";
                    $icon = "fas fa-cloud-sun";
                } else {
                    $greeting = "Selamat Malam";
                    $icon = "fas fa-moon";
                }
            ?>
            <h1 class="text-2xl font-bold flex items-center">
                <i class="<?php echo $icon; ?> mr-2"></i>
                <?php echo $greeting; ?>, <?php echo htmlspecialchars($guru['nama']); ?>
            </h1>
        </div>

        <h2 class="text-2xl font-bold mb-6">Aplikasi SISPENDA</h2>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
            <!-- E-RAPOR -->
            <a href="https://smpn2tj.my.id" class="bg-gradient-to-r from-blue-400 to-blue-600 text-white p-6 rounded-lg shadow-lg flex items-center space-x-4 transform transition duration-500 hover:scale-105">
                <i class="fas fa-book text-3xl"></i>
                <h3 class="text-xl font-bold">E-RAPOR</h3>
            </a>
            <!-- BANK SOAL -->
            <a href="soal_pasusp9" class="bg-gradient-to-r from-green-400 to-green-600 text-white p-6 rounded-lg shadow-lg flex items-center space-x-4 transform transition duration-500 hover:scale-105">
                <i class="fas fa-file-alt text-3xl"></i>
                <h3 class="text-xl font-bold">BANK SOAL</h3>
            </a>
            <!-- REKAP NILAI SISWA -->
            <a href="rank.php" class="bg-gradient-to-r from-yellow-400 to-yellow-600 text-white p-6 rounded-lg shadow-lg flex items-center space-x-4 transform transition duration-500 hover:scale-105">
                <i class="fas fa-list text-3xl"></i>
                <h3 class="text-xl font-bold">REKAP NILAI SISWA</h3>
            </a>
            <!-- REKAP ABSEN GURU -->
            <a href="check_link.php" class="bg-gradient-to-r from-red-400 to-red-600 text-white p-6 rounded-lg shadow-lg flex items-center space-x-4 transform transition duration-500 hover:scale-105">
                <i class="fas fa-calendar-check text-3xl"></i>
                <h3 class="text-xl font-bold">REKAP ABSEN GURU</h3>
            </a>
            <!-- DOWNLOAD SERTIFIKAT -->
            <a href="https://smpn2tungkaljaya.sch.id/download-sertifikat-bedapem/" class="bg-gradient-to-r from-purple-400 to-purple-600 text-white p-6 rounded-lg shadow-lg flex items-center space-x-4 transform transition duration-500 hover:scale-105">
                <i class="fas fa-download text-3xl"></i>
                <h3 class="text-xl font-bold">DOWNLOAD SERTIFIKAT</h3>
            </a>
            <!-- UPLOAD BERKAS PMM -->
            <a href="upload_berkas_pmm.php" class="bg-gradient-to-r from-teal-400 to-teal-600 text-white p-6 rounded-lg shadow-lg flex items-center space-x-4 transform transition duration-500 hover:scale-105">
                <i class="fas fa-upload text-3xl"></i>
                <h3 class="text-xl font-bold">UPLOAD BERKAS PMM</h3>
            </a>
        </div>

        <!-- Notifikasi Pengumuman Terbaru -->
        <?php if ($notifs): ?>
            <div id="notifikasi" class="bg-[#d0f4f7] p-6 rounded-lg shadow-lg mb-6">
                <h3 class="text-xl font-bold mb-4">Pengumuman Terbaru <i class="fas fa-bell text-yellow-500"></i></h3>
                <?php foreach ($notifs as $notif): ?>
                    <div class="mb-4">
                        <h4 class="text-lg font-semibold flex items-center">
                            <i class="fas fa-bullhorn mr-2"></i>
                            <?php echo htmlspecialchars($notif['judul']); ?>
                            <span class="ml-2 text-red-500 blink">NEW!</span>
                        </h4>
                        <div class="prose max-w-none">
                            <?php echo htmlspecialchars_decode($notif['isi']); ?>
                        </div>
                        <small class="text-gray-500">Tanggal: <?php echo htmlspecialchars($notif['tanggal']); ?></small>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <!-- Daftar Pengumuman yang Sudah Ada -->
        <div class="bg-[#f0f4f8] p-6 rounded-lg shadow-lg">
            <h3 class="text-xl font-bold mb-4">Pengumuman Lainnya</h3>
            <?php if (count($pengumumans) > 0): ?>
                <?php foreach ($pengumumans as $pengumuman): ?>
                    <div class="mb-4">
                        <h4 class="text-lg font-semibold flex items-center">
                            <i class="fas fa-bullhorn mr-2"></i>
                            <?php echo htmlspecialchars($pengumuman['judul']); ?>
                        </h4>
                        <p><?php echo htmlspecialchars_decode($pengumuman['isi']); ?></p>
                        <small class="text-gray-500">Tanggal: <?php echo $pengumuman['tanggal']; ?></small>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Belum ada pengumuman yang diterbitkan.</p>
            <?php endif; ?>
        </div>

        <!-- Tombol Melayang untuk Informasi Developer -->
        <a href="javascript:void(0);" class="floating-button" onclick="toggleDeveloperInfo()">
            <i class="fas fa-info-circle"></i>
        </a>
        
        <div id="developer-info" class="hidden absolute bottom-24 right-5 bg-white text-black p-4 rounded-lg shadow-lg">
            <h3 class="font-bold mb-1">Developer Aplikasi:</h3>
            <p>Rudy Susanto, S.Pd</p>
            <p>Aplikasi ini menggunakan teknologi:</p>
            <ul class="list-disc ml-4">
                <li>PHP</li>
                <li>MySQL</li>
                <li>Tailwind CSS</li>
                <li>Font Awesome</li>
                <li>HTML5</li>
                <li>CSS3</li>
                <li>JavaScript</li>
                <li>Fetch API</li>
            </ul>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-gray-800 text-white py-4 w-full">
        <div class="container mx-auto text-center">
            <p>&copy; <?php echo date("Y"); ?> SISPENDA Versi 1.2.2 Developed with <i class="fas fa-coffee text-brown-500"></i> by <a href="https://rdsusanto.my.id" class="text-blue-400 hover:underline">Rudy Susanto</a></p>
        </div>
    </footer>

    <script>
        document.getElementById('notif-bell').addEventListener('click', function() {
            <?php if ($notifs): ?>
                alert('Halo <?php echo htmlspecialchars($guru['nama']); ?>, ada notif terbaru.');
                fetch('tandai_dibaca.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ guru_id: <?php echo $guru_id; ?> })
                });
            <?php else: ?>
                alert('Tidak ada notif hari ini.');
            <?php endif; ?>
        });

        function toggleDeveloperInfo() {
            const info = document.getElementById('developer-info');
            if (info.classList.contains('hidden')) {
                info.classList.remove('hidden');
            } else {
                info.classList.add('hidden');
            }
        }
    </script>
</body>
</html>